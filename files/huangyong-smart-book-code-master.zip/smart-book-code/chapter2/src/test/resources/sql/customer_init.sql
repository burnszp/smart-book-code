TRUNCATE customer;
INSERT INTO customer (name, contact, telephone, email, remark) VALUES ('customer1', 'Jack', '13512345678', 'jack@gmail.com', null);
INSERT INTO customer (name, contact, telephone, email, remark) VALUES ('customer2', 'Rose', '13623456789', 'rose@gmail.com', null);